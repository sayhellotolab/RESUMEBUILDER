import html2pdf from 'html2pdf.js';

const isIos = () =>
  /iPad|iPhone|iPod/.test(navigator.userAgent) ||
  // iPadOS 13+ reports as Mac but has touch support
  (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

/**
 * Exports the given DOM element to a paginated A4 PDF.
 *
 * Mobile note: PDF generation (html2canvas render + jsPDF build) is async,
 * so by the time the file is ready, the browser may no longer treat it as
 * tied to the user's tap. iOS Safari in particular then silently blocks the
 * programmatic `<a download>` click. To avoid this we open a blank tab
 * SYNCHRONOUSLY inside the click handler (preserving the "user gesture"),
 * then navigate that tab to the finished PDF once it's ready. Desktop and
 * Android still get a normal file download.
 *
 * Note: html2pdf.js uses html2canvas internally to rasterize the element.
 * This project aliases `html2canvas` -> `html2canvas-pro` in vite.config.ts
 * so modern CSS color functions (oklch/color-mix from Tailwind v4) render
 * correctly instead of throwing during capture.
 */
export const exportToPdf = (elementId: string, filename: string = 'Document.pdf') => {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`Element with id "${elementId}" not found for PDF export.`);
    return;
  }

  // Must be called synchronously within the click handler, before any
  // await/async work, or mobile browsers will block it as a popup.
  const preOpenedTab = isIos() ? window.open('', '_blank') : null;

  // The on-screen preview is visually shrunk on small viewports via
  // `.pdf-container-scaler { transform: scale(...) }` (see index.css).
  // html2canvas can pick up that ancestor transform and capture a
  // scaled-down/cropped image on phones. Neutralize it for the duration
  // of the capture, then restore it.
  const scaler = element.parentElement?.classList.contains('pdf-container-scaler')
    ? (element.parentElement as HTMLElement)
    : null;
  const previousTransform = scaler?.style.transform;
  if (scaler) {
    scaler.style.transform = 'none';
  }

  const options = {
    margin: 0,
    filename,
    image: { type: 'jpeg' as const, quality: 0.98 },
    html2canvas: {
      scale: 2,
      useCORS: true,
      logging: false,
      windowWidth: element.scrollWidth,
      windowHeight: element.scrollHeight,
    },
    jsPDF: {
      unit: 'mm',
      format: 'a4',
      orientation: 'portrait' as const,
    },
    pagebreak: { mode: ['avoid-all', 'css', 'legacy'] },
  };

  const restoreScaler = () => {
    if (scaler) {
      scaler.style.transform = previousTransform ?? '';
    }
  };

  const worker = html2pdf().set(options).from(element);

  if (preOpenedTab) {
    // iOS path: build as a blob, then point the already-open tab at it so
    // the user can view/share/save it (iOS blocks forced downloads, but
    // viewing in-tab + the native Share button works reliably).
    worker
      .outputPdf('blob')
      .then((blob: Blob) => {
        restoreScaler();
        const url = URL.createObjectURL(blob);
        if (preOpenedTab) {
          preOpenedTab.location.href = url;
        }
        // Give the tab time to load the blob before revoking it.
        setTimeout(() => URL.revokeObjectURL(url), 60_000);
      })
      .catch((err: unknown) => {
        restoreScaler();
        preOpenedTab?.close();
        console.error('PDF export failed:', err);
      });
  } else {
    // Desktop / Android: normal direct-download flow.
    worker
      .save()
      .then(() => restoreScaler())
      .catch((err: unknown) => {
        restoreScaler();
        console.error('PDF export failed:', err);
      });
  }
};
